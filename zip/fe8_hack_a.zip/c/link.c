/*
 * list.c
 *
 *  Created on: 2015年2月26日
 *      Author: yimi
 */

#define SECTION(x) __attribute__((section(x)))

void _8089A00(){

}

void _8089910(){

}
void _80890BC(){

}
